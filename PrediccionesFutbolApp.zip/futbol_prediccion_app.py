import streamlit as st
import pandas as pd

# Título de la app
st.title("⚽ Predicción de Partidos de Fútbol")
st.markdown("Ingresa dos equipos y obtén un análisis comparativo con predicción de resultado.")

# Entrada de equipos
equipo_local = st.text_input("🔵 Equipo Local", value="Bayern de Múnich")
equipo_visitante = st.text_input("🔴 Equipo Visitante", value="Inter de Milán")

if equipo_local and equipo_visitante:
    st.subheader(f"📅 Análisis: {equipo_local} vs {equipo_visitante}")

    # Simulación de factores clave
    data = {
        "Factor": [
            "Forma reciente",
            "Historial directo",
            "Condición de local",
            "Lesiones y ausencias",
            "Defensa del rival",
            "Cuotas de apuestas"
        ],
        equipo_local: [8.5, 7.0, 9.0, 5.0, 6.0, 8.0],
        equipo_visitante: [7.5, 6.0, 6.5, 7.0, 8.5, 7.0]
    }

    df = pd.DataFrame(data)
    df["Ponderación"] = [0.2, 0.15, 0.2, 0.1, 0.15, 0.2]
    df["Score " + equipo_local] = df[equipo_local] * df["Ponderación"]
    df["Score " + equipo_visitante] = df[equipo_visitante] * df["Ponderación"]

    total_local = df["Score " + equipo_local].sum()
    total_visitante = df["Score " + equipo_visitante].sum()

    st.markdown("### 📊 Comparativa de Factores")
    st.dataframe(df[["Factor", equipo_local, equipo_visitante]])

    # Predicción probabilística
    total = total_local + total_visitante
    draw_factor = 0.15  # Factor de empate

    prob_local = (total_local / total) * (1 - draw_factor)
    prob_visitante = (total_visitante / total) * (1 - draw_factor)
    prob_draw = draw_factor

    st.markdown("### 🔮 Predicción del Resultado")
    pred_data = pd.DataFrame({
        "Resultado": [f"Victoria {equipo_local}", "Empate", f"Victoria {equipo_visitante}"],
        "Probabilidad (%)": [
            round(prob_local * 100, 1),
            round(prob_draw * 100, 1),
            round(prob_visitante * 100, 1)
        ]
    })
    st.table(pred_data)

    # Recomendación final
    if prob_local > prob_visitante:
        st.success(f"📌 {equipo_local} tiene una ligera ventaja en este partido.")
    elif prob_visitante > prob_local:
        st.success(f"📌 {equipo_visitante} parece llegar más sólido.")
    else:
        st.info("📌 ¡Partido muy parejo! Todo puede pasar.")

else:
    st.warning("Por favor, ingresa ambos equipos para comenzar el análisis.")
